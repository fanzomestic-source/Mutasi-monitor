# DANA Mutasi Monitor — Android Studio source

This is a source project, not a precompiled APK. Open the folder in Android Studio and build the APK.

## What it does
- Opens the installed DANA app when you tap **Buka DANA**.
- Provides an Accessibility Service that can read visible text from the screen only after the user explicitly enables it in Android Settings.
- Saves captured visible text locally with a timestamp.
- Includes an optional EnginePay endpoint field. No endpoint is assumed or hard-coded; configure it only if you have a compatible endpoint.

## Important limitations
- This is NOT an official DANA API integration and cannot guarantee a complete bank/e-wallet statement.
- The service does not automatically tap through DANA, bypass login, read PIN/OTP, or defeat screen protections.
- It captures only text exposed by Android accessibility on the current screen. DANA may hide transaction details or expose only part of the history.
- EnginePay forwarding is not enabled by default. The server endpoint and expected API format must be confirmed before reliable integration can be implemented.
- Android may restrict background activity; keep the app/service permitted by your device settings if needed.

## Build
1. Install Android Studio with Android SDK Platform 35 and JDK 17 or newer.
2. Open this folder in Android Studio.
3. Wait for Gradle sync.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Enable the service from the app's **Aktifkan pembaca layar** button. Android will open Accessibility settings; enable **DANA Mutasi Monitor** manually.
6. Open DANA and navigate to its transaction/history page. The app records text that is actually exposed to Accessibility.

Minimum Android API: 24 (Android 7.0). Target SDK: 35.
