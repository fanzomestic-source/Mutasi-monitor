package id.enginepay.danamutasi

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DanaAccessibilityService : AccessibilityService() {
    private var lastSaved = ""
    private var lastSaveTime = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val packageName = event.packageName?.toString() ?: return
        // Only capture the DANA app; do not inspect other apps.
        if (packageName != "id.dana") return

        val root = rootInActiveWindow ?: return
        val collected = linkedSetOf<String>()
        collectText(root, collected)
        val text = collected.joinToString("\n").trim()
        if (text.isBlank() || text == lastSaved) return

        val now = System.currentTimeMillis()
        if (now - lastSaveTime < 1200L && text.length < lastSaved.length) return
        lastSaved = text
        lastSaveTime = now

        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(now))
        val payload = "Ditangkap: $stamp\n$text"
        getSharedPreferences("capture", MODE_PRIVATE).edit()
            .putString("latest_text", payload)
            .putLong("latest_timestamp", now)
            .apply()
    }

    private fun collectText(node: AccessibilityNodeInfo?, output: MutableSet<String>) {
        if (node == null) return
        val visibleText = node.text?.toString()?.trim().orEmpty()
        if (visibleText.isNotBlank()) output.add(visibleText)
        val description = node.contentDescription?.toString()?.trim().orEmpty()
        if (description.isNotBlank()) output.add(description)
        for (i in 0 until node.childCount) {
            collectText(node.getChild(i), output)
        }
    }

    override fun onInterrupt() = Unit
}
