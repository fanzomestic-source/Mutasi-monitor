package id.enginepay.danamutasi

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var endpoint: EditText
    private lateinit var preview: TextView
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)

        content.addView(TextView(this).apply {
            text = "DANA Mutasi Monitor"
            textSize = 25f
        })
        content.addView(TextView(this).apply {
            text = "Membaca teks yang tersedia pada layar DANA. Bukan aplikasi resmi DANA."
            textSize = 14f
            setPadding(0, 10, 0, 18)
        })

        status = TextView(this).apply { textSize = 15f }
        content.addView(status)

        content.addView(makeButton("Aktifkan pembaca layar") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        content.addView(makeButton("Buka DANA") { openDana() })
        content.addView(makeButton("Lihat hasil tangkapan") { refreshPreview() })

        content.addView(TextView(this).apply {
            text = "URL EnginePay (opsional)"
            textSize = 16f
            setPadding(0, 18, 0, 4)
        })
        endpoint = EditText(this).apply {
            hint = "https://server-anda.example/api/transactions"
            setSingleLine(true)
            setText(prefs.getString("endpoint", ""))
        }
        content.addView(endpoint)
        content.addView(makeButton("Simpan URL") {
            prefs.edit().putString("endpoint", endpoint.text.toString().trim()).apply()
            Toast.makeText(this, "URL disimpan. Pengiriman belum aktif sampai format API EnginePay dikonfirmasi.", Toast.LENGTH_LONG).show()
        })

        content.addView(TextView(this).apply {
            text = "Catatan: aplikasi hanya menangkap teks yang Android/DANA izinkan untuk diakses. Anda tetap perlu membuka halaman riwayat transaksi DANA. Kelengkapan mutasi tidak dijamin."
            textSize = 13f
            setPadding(0, 18, 0, 10)
        })
        preview = TextView(this).apply { textSize = 13f }
        content.addView(preview)

        layout.addView(scroll, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        setContentView(layout)
        refreshStatus()
        refreshPreview()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setOnClickListener { action() }
        }

    private fun openDana() {
        val launch = packageManager.getLaunchIntentForPackage("id.dana")
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launch)
        } else {
            Toast.makeText(this, "Aplikasi DANA tidak ditemukan. Instal DANA terlebih dahulu.", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=id.dana")))
            } catch (_: Exception) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=id.dana")))
            }
        }
    }

    private fun refreshStatus() {
        val enabled = try {
            val enabledServices = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
            enabledServices.contains(ComponentName(this, DanaAccessibilityService::class.java).flattenToString(), ignoreCase = true)
        } catch (_: Exception) { false }
        status.text = if (enabled) "Status pembaca layar: AKTIF" else "Status pembaca layar: BELUM AKTIF"
    }

    private fun refreshPreview() {
        val rows = getSharedPreferences("capture", MODE_PRIVATE).getString("latest_text", "").orEmpty()
        preview.text = if (rows.isBlank()) "Belum ada teks yang ditangkap. Aktifkan layanan, buka DANA, lalu masuk ke riwayat transaksi." else "Teks terakhir yang ditangkap:\n\n$rows"
    }
}
