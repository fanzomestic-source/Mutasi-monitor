plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "id.enginepay.danamutasi"
    compileSdk = 35

    defaultConfig {
        applicationId = "id.enginepay.danamutasi"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
